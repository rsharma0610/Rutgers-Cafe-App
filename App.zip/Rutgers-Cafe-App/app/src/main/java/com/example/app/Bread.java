package com.example.app;

/**
 * Enum class representing the different bread options
 * @Author Rohan Sharma and Joseph Veliz
 */
public enum Bread {
    BAGEL,
    WHEATBREAD,
    SOURDOUGH
}
