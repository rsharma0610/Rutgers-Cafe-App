package com.example.app;

/**
 * DonutType enum class representing the different donut types
 */
public enum DonutType {
    YEAST,
    CAKE,
    HOLE
}
