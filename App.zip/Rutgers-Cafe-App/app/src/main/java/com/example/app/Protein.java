package com.example.app;

/**
 * Protein enum class representing the different protein options
 */
public enum Protein {
    BEEF,
    FISH,
    CHICKEN
}
