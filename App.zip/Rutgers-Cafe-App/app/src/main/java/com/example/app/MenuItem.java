package com.example.app;

/**
 * MenuItem abstract class for menu item objects
 */
public abstract class MenuItem {
    public abstract double price();
}
